@echo off
setlocal
title GD4 Assistant - Relais local (port 9091)
cd /d "%~dp0"

echo ============================================================
echo    GD4 ASSISTANT - Relais local (pont Godot ^<-^> application)
echo ============================================================
echo.

where python >nul 2>&1
if errorlevel 1 goto nopython

echo [1/3] Verification des dependances (fastapi, uvicorn, httpx)...
python -m pip install --quiet --disable-pip-version-check -r requirements.txt
if errorlevel 1 goto pipfail

echo [2/3] Demarrage du relais sur http://127.0.0.1:9091 ...
start "" http://127.0.0.1:9091/
echo [3/3] Laisse cette fenetre OUVERTE pendant ta session Godot.
echo       (Ctrl+C ou fermer la fenetre = relais arrete)
echo.
python server.py
echo.
echo Relais arrete.
pause
exit /b 0

:nopython
echo [ERREUR] Python n'a pas ete trouve.
echo Installe Python 3.10 ou plus : https://www.python.org/downloads/
echo Pendant l'installation, coche "Add python.exe to PATH".
echo.
pause
exit /b 1

:pipfail
echo [ERREUR] Installation des dependances impossible.
echo Verifie ta connexion internet puis relance ce fichier.
echo.
pause
exit /b 1
