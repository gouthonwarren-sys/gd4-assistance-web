﻿@tool
extends EditorPlugin

# ==============================================================================
#  GD4 Assistance — Dock de l'éditeur Godot 4
#  Thème sombre « Mocha », cohérent avec l'interface web de l'app.
# ==============================================================================

const VERSION := "1.3.1"

# --- Réseau ---
const SETTING_PORT = "gd4_assistance/network/port"
const SETTING_CODE = "gd4_assistance/network/pairing_code"
const RECONNECT_DELAY := 3.0

# --- Palette (identique à static/index.html) ---
const COL_BG       := Color("#12131C")
const COL_PANEL    := Color("#1A1C29")
const COL_CARD     := Color("#15161F")
const COL_FIELD    := Color("#252836")
const COL_HOVER    := Color("#2F3345")
const COL_BORDER   := Color("#2B2D3E")
const COL_ACCENT   := Color("#89B4FA")
const COL_ACCENT_L := Color("#B4BEFE")
const COL_ACCENT_D := Color("#6C8FDB")
const COL_GREEN    := Color("#A6E3A1")
const COL_RED      := Color("#F38BA8")
const COL_YELLOW   := Color("#F9E2AF")
const COL_TEXT     := Color("#CDD6F4")
const COL_DIM      := Color("#6C7086")

# --- Réseau ---
var socket := WebSocketPeer.new()
var is_connected := false
var reconnect_timer := 0.0

# --- Références UI ---
var dock: PanelContainer
var status_pill: PanelContainer
var status_dot: Panel
var status_label: Label
var code_input: LineEdit
var chat_log: RichTextLabel
var prompt_input: LineEdit
var send_btn: Button
var pending_image = null
var status_tween: Tween
var auth_failed_shown := false

func _enter_tree() -> void:
	_init_project_settings()
	_build_dock()
	add_control_to_dock(DOCK_SLOT_RIGHT_UL, dock)
	# Le code est reçu UNIQUEMENT via WebSocket (pairing_update) depuis le serveur
	_connect_to_app()

func _exit_tree() -> void:
	socket.close()
	if status_tween:
		status_tween.kill()
		status_tween = null
	if dock:
		remove_control_from_docks(dock)
		dock.free()

func _init_project_settings() -> void:
	if not ProjectSettings.has_setting(SETTING_PORT):
		ProjectSettings.set_setting(SETTING_PORT, 9091)
	if not ProjectSettings.has_setting(SETTING_CODE):
		ProjectSettings.set_setting(SETTING_CODE, "123456")
	ProjectSettings.save()

func _connect_to_app() -> void:
	var port = ProjectSettings.get_setting(SETTING_PORT)
	var url = "ws://127.0.0.1:" + str(port) + "/ws/godot"
	print("[GD4 Assistance] Connexion vers ", url)
	_set_status("conn")
	socket.connect_to_url(url)

func _reconnect_now() -> void:
	socket.close()
	socket = WebSocketPeer.new()
	is_connected = false
	reconnect_timer = 0.0
	_connect_to_app()

func _process(delta: float) -> void:
	socket.poll()
	var state = socket.get_ready_state()

	match state:
		WebSocketPeer.STATE_OPEN:
			if not is_connected:
				is_connected = true
				reconnect_timer = 0.0
				auth_failed_shown = false
				_set_status("on")
				print("[GD4 Assistance] ✅ Connecté à l'app — handshake envoyé.")
				_send_handshake()
			while socket.get_available_packet_count() > 0:
				var packet = socket.get_packet()
				_on_command_received(packet.get_string_from_utf8())
		WebSocketPeer.STATE_CLOSED:
			if is_connected:
				is_connected = false
				_set_status("off")
				print("[GD4 Assistance] Connexion fermée.")
			reconnect_timer += delta
			if reconnect_timer >= RECONNECT_DELAY:
				reconnect_timer = 0.0
				socket = WebSocketPeer.new()
				_connect_to_app()

func _send_handshake() -> void:
	var raw_code = ProjectSettings.get_setting(SETTING_CODE)
	socket.send_text(JSON.stringify({
		"type": "auth_handshake",
		"pairing_code": str(raw_code).strip_edges(),
		"project_name": ProjectSettings.get_setting("application/config/name"),
		"version": VERSION,
	}))

# ==============================================================================
#  PASTILLE D'ÉTAT (verte / rouge / jaune pulsante)
# ==============================================================================
func _set_status(state: String) -> void:
	if status_label == null or status_pill == null or status_dot == null:
		return
	var dot_col := COL_RED
	var txt := "Déconnecté — colle le code de l'app"
	match state:
		"on":
			dot_col = COL_GREEN
			txt = "Connecté à l'app"
		"conn":
			dot_col = COL_YELLOW
			txt = "Connexion en cours…"

	var bg := Color(dot_col.r, dot_col.g, dot_col.b, 0.13)
	status_label.text = txt
	status_label.add_theme_color_override("font_color", dot_col)
	status_pill.add_theme_stylebox_override(
		"panel", _sb(bg, 8, dot_col, 1, 10, 10, 5, 5))
	status_dot.add_theme_stylebox_override("panel", _sb(dot_col, 99))

	if status_tween:
		status_tween.kill()
		status_tween = null
	status_dot.modulate.a = 1.0
	if state == "conn":
		status_tween = create_tween().set_loops()
		status_tween.tween_property(status_dot, "modulate:a", 0.25, 0.45)
		status_tween.tween_property(status_dot, "modulate:a", 1.0, 0.45)


# ==============================================================================
#  CONSTRUCTION DE L'INTERFACE
# ==============================================================================
func _build_dock() -> void:
	dock = PanelContainer.new()
	dock.name = "GD4 Assistance"
	dock.custom_minimum_size = Vector2(300, 430)
	dock.add_theme_stylebox_override("panel", _sb(COL_BG, 10))

	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 10)
	margin.add_theme_constant_override("margin_right", 10)
	margin.add_theme_constant_override("margin_top", 10)
	margin.add_theme_constant_override("margin_bottom", 10)
	dock.add_child(margin)

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 8)
	margin.add_child(vbox)

	# ---- En-tête ------------------------------------------------------------
	var header := HBoxContainer.new()
	header.add_theme_constant_override("separation", 8)
	vbox.add_child(header)

	var logo := PanelContainer.new()
	logo.custom_minimum_size = Vector2(30, 30)
	logo.add_theme_stylebox_override("panel", _sb(COL_ACCENT, 9))
	var cc := CenterContainer.new()
	logo.add_child(cc)
	var logo_lbl := Label.new()
	logo_lbl.text = "G4"
	logo_lbl.add_theme_font_size_override("font_size", 13)
	logo_lbl.add_theme_color_override("font_color", COL_BG)
	cc.add_child(logo_lbl)
	header.add_child(logo)

	var titles := VBoxContainer.new()
	titles.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	titles.add_theme_constant_override("separation", 0)
	header.add_child(titles)
	var name_lbl := Label.new()
	name_lbl.text = "GD4 ASSISTANCE"
	name_lbl.add_theme_font_size_override("font_size", 14)
	name_lbl.add_theme_color_override("font_color", COL_TEXT)
	titles.add_child(name_lbl)
	var ver_lbl := Label.new()
	ver_lbl.text = "v%s · assistant IA" % VERSION
	ver_lbl.add_theme_font_size_override("font_size", 10)
	ver_lbl.add_theme_color_override("font_color", COL_DIM)
	titles.add_child(ver_lbl)

	vbox.add_child(_rule())

	# ---- Pastille d'état ----------------------------------------------------
	status_pill = PanelContainer.new()
	vbox.add_child(status_pill)
	var pill_row := HBoxContainer.new()
	pill_row.add_theme_constant_override("separation", 8)
	status_pill.add_child(pill_row)

	status_dot = Panel.new()
	status_dot.custom_minimum_size = Vector2(9, 9)
	status_dot.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	pill_row.add_child(status_dot)

	status_label = Label.new()
	pill_row.add_child(status_label)

	# ---- Appairage ----------------------------------------------------------
	vbox.add_child(_section("Appairage"))

	code_input = LineEdit.new()
	code_input.placeholder_text = "Code de l'app (ex : GD4-1234)"
	code_input.text = str(ProjectSettings.get_setting(SETTING_CODE))
	code_input.custom_minimum_size.y = 32
	code_input.select_all_on_focus = true
	_style_line_edit(code_input)
	code_input.text_submitted.connect(func(_t): _on_connect_pressed())
	vbox.add_child(code_input)

	var connect_btn := Button.new()
	connect_btn.text = "🔗  Connecter"
	connect_btn.tooltip_text = "Enregistre le code et relance la connexion"
	connect_btn.custom_minimum_size.y = 32
	_style_button(connect_btn, COL_ACCENT, COL_ACCENT_L, COL_ACCENT_D, COL_BG, true)
	connect_btn.pressed.connect(_on_connect_pressed)
	vbox.add_child(connect_btn)


	vbox.add_child(_section("Conversation"))

	# ---- Journal ------------------------------------------------------------
	var chat_card := PanelContainer.new()
	chat_card.add_theme_stylebox_override("panel", _sb(COL_CARD, 8, COL_BORDER, 1))
	chat_card.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vbox.add_child(chat_card)

	var chat_pad := MarginContainer.new()
	chat_pad.add_theme_constant_override("margin_left", 10)
	chat_pad.add_theme_constant_override("margin_right", 10)
	chat_pad.add_theme_constant_override("margin_top", 8)
	chat_pad.add_theme_constant_override("margin_bottom", 8)
	chat_card.add_child(chat_pad)

	chat_log = RichTextLabel.new()
	chat_log.bbcode_enabled = true
	chat_log.scroll_following = true
	chat_log.selection_enabled = true
	chat_log.add_theme_constant_override("line_separation", 5)
	chat_log.add_theme_font_size_override("normal_font_size", 13)
	chat_log.add_theme_font_size_override("bold_font_size", 13)
	chat_log.add_theme_font_size_override("italics_font_size", 13)
	chat_log.add_theme_color_override("default_color", COL_TEXT)
	chat_pad.add_child(chat_log)

	# ---- Saisie + actions ---------------------------------------------------
	prompt_input = LineEdit.new()
	prompt_input.placeholder_text = "Ex : crée un Node2D nommé Test…"
	prompt_input.custom_minimum_size.y = 34
	_style_line_edit(prompt_input)
	prompt_input.text_submitted.connect(func(_t): _send_prompt())
	vbox.add_child(prompt_input)

	var actions := HBoxContainer.new()
	actions.add_theme_constant_override("separation", 8)
	vbox.add_child(actions)

	var capture_btn := Button.new()
	capture_btn.text = "📸 Capture"
	capture_btn.tooltip_text = "Ajoute une capture d'écran à ta prochaine question"
	capture_btn.custom_minimum_size.y = 32
	_style_button(capture_btn, COL_FIELD, COL_HOVER, COL_BORDER, COL_TEXT, false)
	capture_btn.pressed.connect(_on_capture_pressed)
	actions.add_child(capture_btn)

	var clear_btn := Button.new()
	clear_btn.text = "🗑"
	clear_btn.tooltip_text = "Vider le journal"
	clear_btn.custom_minimum_size.y = 32
	_style_button(clear_btn, COL_FIELD, COL_HOVER, COL_BORDER, COL_TEXT, false)
	clear_btn.pressed.connect(_on_clear_chat)
	actions.add_child(clear_btn)

	var spacer := Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	actions.add_child(spacer)

	send_btn = Button.new()
	send_btn.text = "🤖 Envoyer ▸"
	send_btn.tooltip_text = "Envoie la question à l'app (Entrée fonctionne aussi)"
	send_btn.custom_minimum_size.y = 32
	_style_button(send_btn, COL_ACCENT, COL_ACCENT_L, COL_ACCENT_D, COL_BG, true)
	send_btn.pressed.connect(_send_prompt)
	actions.add_child(send_btn)

	_chat("info", "Bienvenue ! Ce dock pilote ta scène Godot depuis la console web.")
	_chat("sys", "Colle le code affiché dans l'app puis clique sur Connecter.")

# ==============================================================================
#  AIDES UI (StyleBox, sections, boutons, champs)
# ==============================================================================
func _sb(bg: Color, radius: int = 8, border: Color = Color.TRANSPARENT,
		border_w: int = 0, pad_l: float = 0.0, pad_r: float = 0.0,
		pad_t: float = 0.0, pad_b: float = 0.0) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg
	sb.set_corner_radius_all(radius)
	if border_w > 0:
		sb.border_color = border
		sb.set_border_width_all(border_w)
	sb.content_margin_left = pad_l
	sb.content_margin_right = pad_r
	sb.content_margin_top = pad_t
	sb.content_margin_bottom = pad_b
	return sb

func _rule() -> Panel:
	var rule := Panel.new()
	rule.custom_minimum_size = Vector2(0, 2)
	rule.add_theme_stylebox_override("panel",
		_sb(Color(COL_ACCENT.r, COL_ACCENT.g, COL_ACCENT.b, 0.35), 2))
	return rule

func _section(text: String) -> Label:
	var lbl := Label.new()
	lbl.text = text.to_upper()
	lbl.add_theme_font_size_override("font_size", 11)
	lbl.add_theme_color_override("font_color", COL_DIM)
	return lbl

func _style_button(btn: Button, normal: Color, hover: Color, pressed: Color,
		fg: Color, big := false) -> void:
	btn.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	btn.add_theme_stylebox_override("normal", _sb(normal, 7))
	btn.add_theme_stylebox_override("hover", _sb(hover, 7))
	btn.add_theme_stylebox_override("pressed", _sb(pressed, 7))
	btn.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	for c in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color"]:
		btn.add_theme_color_override(c, fg)
	if big:
		btn.add_theme_font_size_override("font_size", 13)

func _style_line_edit(edit: LineEdit) -> void:
	edit.add_theme_stylebox_override("normal",
		_sb(COL_PANEL, 7, COL_BORDER, 1, 9, 9, 5, 5))
	edit.add_theme_stylebox_override("focus",
		_sb(COL_PANEL, 7, COL_ACCENT, 1, 9, 9, 5, 5))
	edit.add_theme_color_override("font_color", COL_TEXT)
	edit.add_theme_color_override("font_placeholder_color", COL_DIM)
	edit.add_theme_color_override("caret_color", COL_ACCENT)
	edit.add_theme_color_override("selection_color",
		Color(COL_ACCENT.r, COL_ACCENT.g, COL_ACCENT.b, 0.25))


# ==============================================================================
#  JOURNAL DE CONVERSATION
# ==============================================================================
func _chat(kind: String, text: String, tag: String = "") -> void:
	if chat_log == null:
		return
	var esc: String = text.replace("[", "[lb]")
	var stamp: String = Time.get_time_string_from_system().substr(0, 5)
	match kind:
		"user":
			chat_log.append_text("[color=#6C7086]%s ·[/color] " % stamp)
			chat_log.append_text("[color=#F9E2AF][b]Vous[/b][/color]")
			if tag != "":
				chat_log.append_text(" [color=#6C7086]%s[/color]"
					% tag.replace("[", "[lb]"))
			chat_log.append_text("\n%s\n\n" % esc)
		"ai":
			chat_log.append_text("[color=#6C7086]%s ·[/color] " % stamp)
			chat_log.append_text("[color=#A6E3A1][b]◆ IA[/b][/color]")
			if tag != "":
				chat_log.append_text(" [color=#6C7086]%s[/color]"
					% tag.replace("[", "[lb]"))
			chat_log.append_text("\n%s\n\n" % esc)
		"info":
			chat_log.append_text("[i][color=#89B4FA]%s[/color][/i]\n\n" % esc)
		"ok":
			chat_log.append_text("[i][color=#A6E3A1]✔ %s[/color][/i]\n\n" % esc)
		"warn":
			chat_log.append_text("[i][color=#F9E2AF]⚠️ %s[/color][/i]\n\n" % esc)
		"err":
			chat_log.append_text("[i][color=#F38BA8]✖ %s[/color][/i]\n\n" % esc)
		_:
			chat_log.append_text("[i][color=#6C7086]%s[/color][/i]\n\n" % esc)

func _on_clear_chat() -> void:
	chat_log.clear()
	_chat("sys", "Journal vidé.")

# ==============================================================================
#  ACTIONS UTILISATEUR
# ==============================================================================
func _on_connect_pressed() -> void:
	var code = code_input.text.strip_edges()
	if code.is_empty():
		_chat("warn", "Saisis d'abord un code d'appairage.")
		return
	ProjectSettings.set_setting(SETTING_CODE, code)
	ProjectSettings.save()
	auth_failed_shown = false
	_chat("info", "Code enregistré (%s) — reconnexion…"
		% code.replace("[", "[lb]"))
	_reconnect_now()

func _on_capture_pressed() -> void:
	pending_image = _do_capture()
	if pending_image is String and not (pending_image as String).is_empty():
		_chat("ok", "Capture prête — elle sera jointe à ta prochaine question.")
	else:
		pending_image = null
		_chat("err", "Capture impossible.")

func _send_prompt() -> void:
	var text = prompt_input.text.strip_edges()
	if text.is_empty():
		return
	if not is_connected:
		_chat("err", "Non connecté à l'app — vérifie ton code d'appairage.")
		return

	var attached := false
	if pending_image is String and not (pending_image as String).is_empty():
		attached = true

	prompt_input.text = ""
	_chat("sys", "⏳ L'app réfléchit…")
	_chat("user", ("📷 " if attached else "") + text)

	socket.send_text(JSON.stringify({
		"type": "plugin_chat",
		"prompt": text,
		"image": pending_image,
	}))
	pending_image = null


# ==============================================================================
#  RÉCEPTION DES COMMANDES
# ==============================================================================
func _on_command_received(message_text: String) -> void:
	var json = JSON.parse_string(message_text)
	if not json is Dictionary:
		return

	# L'app a RÉGÉNÉRÉ le code et nous le pousse directement → on l'adopte
	if json.get("type", "") == "pairing_update":
		var new_code = str(json.get("pin", "")).strip_edges()
		if not new_code.is_empty():
			ProjectSettings.set_setting(SETTING_CODE, new_code)
			ProjectSettings.save()
			if code_input:
				code_input.text = new_code
			auth_failed_shown = false
			_chat("ok", "L'app a changé le code → synchronisé : " + new_code)
		return

	# L'app a refusé notre code → il faut le recopier manuellement depuis l'app
	if json.get("type", "") == "auth_failed":
		if not auth_failed_shown:
			auth_failed_shown = true
			_chat("err", "Code d'appairage refusé par l'app — copie le code affiché dans l'app, colle-le ici puis clique sur Connecter.")
		return

	if json.get("type", "") == "ai_result":
		_chat("ai", str(json.get("explanation", "")), str(json.get("model", "")))
		var actions = json.get("actions", [])
		if actions is Array and actions.size() > 0:
			var done: int = _apply_ai_actions(actions)
			_chat("ok", "%d/%d action(s) appliquée(s) à la scène."
				% [done, actions.size()])
		return

	if not json.has("command"):
		return

	match json["command"]:
		"capture_screen":
			var b64 = _do_capture()
			if b64 != "":
				socket.send_text(JSON.stringify(
					{"type": "screenshot_response", "data": b64}))
				_chat("ok", "Capture transmise à l'app.")
			else:
				_chat("err", "Échec de la capture demandée par l'app.")
		"apply_actions":
			var acts = json.get("actions", [])
			if acts is Array and acts.size() > 0:
				var done2: int = _apply_ai_actions(acts)
				_chat("ok", "%d/%d action(s) appliquée(s) à la scène."
					% [done2, acts.size()])
		"request_context":
			_send_full_context()

# ==============================================================================
#  CAPTURE D'ÉCRAN
# ==============================================================================
func _do_capture() -> String:
	var vp: Viewport = null
	var root = EditorInterface.get_edited_scene_root()
	if root != null:
		vp = root.get_viewport()
	if vp == null:
		vp = EditorInterface.get_base_control().get_viewport()
	if vp == null:
		return ""
	var texture = vp.get_texture()
	if texture == null:
		return ""
	var img = texture.get_image()
	if img == null or img.is_empty():
		return ""
	return Marshalls.raw_to_base64(img.save_png_to_buffer())

# ==============================================================================
#  CONTEXTE DE SCÈNE
# ==============================================================================
func _send_full_context() -> void:
	var scene_root = EditorInterface.get_edited_scene_root()
	var scene_tree_data = []
	if scene_root:
		scene_tree_data = _serialize_node(scene_root)
	socket.send_text(JSON.stringify({
		"type": "context_response",
		"scene_name": scene_root.name if scene_root else "Aucune scène",
		"scene_tree": scene_tree_data,
	}))

func _serialize_node(node: Node) -> Dictionary:
	var children = []
	for child in node.get_children():
		children.append(_serialize_node(child))
	return {
		"name": node.name,
		"class": node.get_class(),
		"has_script": node.get_script() != null,
		"children": children,
	}


# ==============================================================================
#  EXÉCUTEUR D'ACTIONS IA
# ==============================================================================
func _apply_ai_actions(actions: Array) -> int:
	var scene_root = EditorInterface.get_edited_scene_root()
	if not scene_root:
		push_warning("[GD4] ⚠️ Aucune scène ouverte")
		return 0
	var applied := 0
	for action in actions:
		if action is Dictionary and _apply_one(scene_root, action):
			applied += 1
	print("[GD4] ✅ ", applied, "/", actions.size(), " action(s) traitée(s)")
	return applied

func _apply_one(root: Node, a: Dictionary) -> bool:
	match a.get("type", ""):
		"create_node":
			return _do_create_node(root, a)
		"set_property":
			return _do_set_property(root, a)
		"create_script":
			return _do_create_script(root, a)
		"connect_signal":
			return _do_connect_signal(root, a)
		_:
			push_warning("[GD4] Type d'action inconnu : " + str(a.get("type")))
			return false

func _find_node(root: Node, path_or_name: String) -> Node:
	if path_or_name == "" or path_or_name == ".":
		return root
	var n = root.get_node_or_null(path_or_name)
	if n == null:
		n = root.find_child(path_or_name, true, false)
	return n

func _set_owner(n: Node, root: Node) -> void:
	n.owner = root
	for c in n.get_children():
		_set_owner(c, root)

func _do_create_node(root: Node, a: Dictionary) -> bool:
	var parent = _find_node(root, a.get("parent", "."))
	if parent == null:
		parent = root
	var t = str(a.get("node_type", "Node2D"))
	if not ClassDB.can_instantiate(t):
		push_warning("[GD4] Type de nœud inconnu : " + t)
		return false
	var n = ClassDB.instantiate(t)
	n.name = a.get("name", t)
	parent.add_child(n)
	_set_owner(n, root)
	print("[GD4] 🌲 Nœud créé : ", n.name)
	return true

func _do_set_property(root: Node, a: Dictionary) -> bool:
	var node = _find_node(root, a.get("node", ""))
	if node == null:
		push_warning("[GD4] Nœud introuvable : " + str(a.get("node")))
		return false
	var raw = a.get("value")
	var value
	if raw is Array:
		if raw.size() == 2:
			value = Vector2(raw[0], raw[1])
		elif raw.size() == 3:
			value = Vector3(raw[0], raw[1], raw[2])
		elif raw.size() == 4:
			value = Color(raw[0], raw[1], raw[2], raw[3])
		else:
			value = raw
	else:
		value = raw
	node.set(str(a.get("property", "")), value)
	print("[GD4] 🔧 Propriété : ", node.name, ".", a.get("property", ""), " = ", value)
	return true

func _do_create_script(root: Node, a: Dictionary) -> bool:
	var node = _find_node(root, a.get("node", ""))
	if node == null:
		push_warning("[GD4] Nœud introuvable : " + str(a.get("node")))
		return false
	DirAccess.make_dir_recursive_absolute("res://ai_generated/scripts/")
	var path = "res://ai_generated/scripts/" + node.name.to_snake_case() + ".gd"
	var gd = GDScript.new()
	gd.source_code = str(a.get("code", ""))
	var err = ResourceSaver.save(gd, path)
	if err != OK:
		push_warning("[GD4] Échec sauvegarde script : " + str(err))
		return false
	node.set_script(load(path))
	EditorInterface.get_resource_filesystem().scan()
	print("[GD4] 📜 Script créé et attaché : ", path)
	return true

func _do_connect_signal(root: Node, a: Dictionary) -> bool:
	var from = _find_node(root, a.get("from_node", ""))
	var to = _find_node(root, a.get("to_node", ""))
	if from == null or to == null:
		push_warning("[GD4] Signal : nœud introuvable")
		return false
	from.connect(str(a.get("signal", "")), Callable(to, str(a.get("method", ""))))
	print("[GD4] 🔌 Signal connecté : ", a.get("signal", ""))
	return true
